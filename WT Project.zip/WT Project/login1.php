<html>
<head>
<title>Login</title>

    <link rel="stylesheet" href="style.css">

</head>
<body>


<?php
    if(isset($_REQUEST['sub']))
    {
        $sub=$_REQUEST['sub'];


        if($sub=="Register")
        {
            $us=$_REQUEST['uid'];
            $pa=$_REQUEST['upw'];
            $role=$_REQUEST['role'];

            $link=new mysqli("localhost","root","","wtproject");

            $link->query("insert into mainlogin values('$us','$pa','$role')");
            $link->close();
           header("location:form.php");
        }
        else if($sub=="Login")
        {
            $us=$_REQUEST['uid'];
            $pa=$_REQUEST['upw'];
            $role=$_REQUEST['role'];

            $link=new mysqli("localhost","root","","gtudb20");

            $res=$link->query("select * from mainlogin where username='$us' and password='$pa' and role='$role'");


            if(mysqli_num_rows($res)>0)
            {
                /*echo "<br> you are authorised user....";*/
                header("location:home.html");
            }
            else{
                header("location:fail.php");
            }
            $link->close();
        }

        
    }
    else
    {

?>
   <!-- <form name="f1" action="basic login phpdatabase.php">
    USER NAME : <input type="text" name="tus"><br><br>
    PASSWORD : <input type="password" name="tpa"><br><br>

    <input type="submit" name="sub" value="LOGIN">
    <input type="submit" name="sub" value="SIGN UP">

    </form>
    -->
    <div class="form-box">

            <div class="button-box">

                <div id="btn"></div>

                <button type="button" class="toggle-btn" onclick="login()">Login</button>

                <button type="button" class="toggle-btn" onclick="register()">Register</button>

            </div>

            <div class="logo-image">

                <img src="login logo.jpg" align="center" alt="Login">

            </div>


            <form class="inp-grp" id="login" action="login1.php">

                <input type="text" class="inp-field" onblur="checkuid()" name="uid" placeholder=" User Id" required>

                <input type="password" class="inp-field" onblur="checkupw()" name="upw" placeholder=" Password" required>
               
                <label>Select Role : </label>
                <select name="role" require>
                    <option value="Trainer">Trainer</option>
                    <option value="User">User</option>
                </select>
                <br>

                <input type="checkbox" class="check-box"><span>Remember Password</span>

                <button type="submit" class="submit-btn" name="sub" value="Login">Login</button>

            </form>



            <form class="inp-grp" id="register" action="login1.php">

                <input type="text" class="inp-field" name="uid" placeholder=" User Id" required>

                <!--<input type="text" class="inp-field"  name="role" placeholder=" ROLE As Trainer or User" required>  -->

                <input type="password" class="inp-field" name="upw" placeholder=" Password" required>

                <label>Select Role : </label>
                <select name="role" require>
                    <option value="Trainer">Trainer</option>
                    <option value="User">User</option>
                </select><br>
                
                <input type="checkbox" class="check-box"><span>I agree to the Terms and Conditions</span>

                <button type="submit" class="submit-btn" name="sub" value="Register">Register</button>
                <!--<a href="form.html">-->

            </form>
    </div>

    <script>

        var x = document.getElementById("login");

        var y = document.getElementById("register");

        var z = document.getElementById("btn");



        function register() {

            x.style.left = "-450px";

            y.style.left = "50px";

            z.style.left = "110px"

        }



        function login() {

            x.style.left = "50px";

            y.style.left = "450px";

            z.style.left = "0px"

        }

    </script>

    <?php

    }
    ?>
</body>
</html>