<html>
<head>
</head>
<body>


<?php
    if(isset($_REQUEST['sub']))
    {
        $sub=$_REQUEST['sub'];

            $fna=$_REQUEST['fna'];
            $lna=$_REQUEST['lna'];
            $mobno=$_REQUEST['mobno'];
            $email=$_REQUEST['email'];
            $una=$_REQUEST['una'];
            $pass=$_REQUEST['pass'];
            $radio=$_REQUEST['male'];

            $link=new mysqli("localhost","root","","wtproject");
            
            $link->query("insert into mainuserinfo values('$fna','$lna','$mobno','$email','$una','$pass','$radio')");
           
            $link->close();
            header("location:home.php");
        
    }
    else
    {

?>
       <form id="registerss" name="f1" action="form.php" style="   width: 500px; margin: 0px 0px 0px 430px; color: white; font-size: 18px;">
            <table BORDER=5 CELLSPACING=50 CELLPADDING=5>
                <tr><td><label>FIRST NAME:</td><td><input type="text" name="fna" id="" placeholder="first name nakho"></td></tr><br>

                <tr><td><label>LAST NAME:</td><td><input type="text" name="lna" id="" placeholder="atak name nakho"></td></tr>

                <tr><td><label>MOBILE:</td><td><input type="NUMBER" name="mobno" id="" placeholder="call me babes"></td></tr>

                <tr><td><label>EMAIL:</td><td><input type="text" name="email" id="" placeholder="ana per tamne email avse"></td></tr>

                <tr><td><label>USER NAME:</td><td><input type="text" name="una" id="" placeholder="username pelvalu nakho"></td></tr>

                <tr><td><label>PASSWORD:</td><td><input type="text" name="pass" id="" placeholder="KOI NE KEHTA NAI"></td></tr>

                <tr><td>GENDER:</td><td>
                <input type="radio" name="male" id="male">male
                <input type="radio" name="male" id="female">female
                <input type="radio" name="male" id="others">others
                </td></tr>

                <tr><td></td><td><input type="submit" value="Submit" name="sub"></td></tr>

            </table>

        </form>

    <?php

    }
    ?>
</body>
</html>